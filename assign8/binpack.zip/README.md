To compile and run this program, please make sure that bin.txt is in the same directory as binpack.cpp
Next, enter the following commands to compile:

g++ -o binpack binpack.cpp

To run, enter:
./binpack
