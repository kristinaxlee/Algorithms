COMPILING AND RUNNING:

To compile this program, enter the following command:
g++ -o assign4 assign4.cpp

To run this program, execute the following command:
./assign4


Please make sure data.txt is in the same folder as the assignment.