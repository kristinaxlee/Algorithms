To compile this program, enter the following command:
g++ -o shopping shopping.cpp

To run this program, execute the following command:
./shopping
